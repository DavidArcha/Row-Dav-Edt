import { Component, OnInit } from '@angular/core';
import { ColDef, GridApi } from 'ag-grid-community';
import { ButtonsComponentComponent } from '../buttons-component/buttons-component.component';

@Component({
  selector: 'app-grid-data',
  templateUrl: './grid-data.component.html',
  styleUrl: './grid-data.component.scss',
})
export class GridDataComponent implements OnInit {
  public rowData: any[] = [];
  public colDefs: ColDef[] = [];
  public paginationPageSize = 5;
  public paginationPageSizeSelector: number[] | boolean = [5, 10, 25, 50];
  public themeClass: string = 'ag-theme-quartz';
  private gridApi!: GridApi; // Explicitly define GridApi
  currentPage = 1; // Initial page number
  totalRecords = 0; // Total number of records for pagination

  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.colDefs = [
      { headerName: 'Name', field: 'name', editable: true },
      {
        headerName: 'Actions',
        field: 'actions',
        cellRenderer: ButtonsComponentComponent,
      },
    ];

    this.rowData = [
      { name: 'John', id: 1 },
      { name: 'Jane', id: 2 },
    ];
  }
  // Function to load data from the backend
  loadGridData(pageNumber: number, pageSize: number) {
    const startRecord = (pageNumber - 1) * pageSize;
    console.log('loadGrid Data : ', startRecord);

    // Make a request to the backend to get the data
    // this.http.get(`your-backend-api-url`, {
    //   params: {
    //     page: pageNumber.toString(),
    //     pageSize: pageSize.toString(),
    //     start: startRecord.toString()
    //   }
    // }).subscribe((response: any) => {
    //   // Assuming response contains records and total count
    //   this.rowData = response.records; // Set the grid data
    //   this.totalRecords = response.totalCount; // Total records for pagination (if needed)
    // });
  }

  frameworkComponents = {
    buttonsRenderer: ButtonsComponentComponent, // Register the component
  };

  gridOptions = {
    columnTypes: {
      editableColumn: {
        editable: true, // Common behavior for editable columns
        cellEditor: 'agTextCellEditor', // You can customize the editor if needed
      },
    },
  };
  onFilterTextBoxChanged() {
    this.gridApi.setGridOption(
      'quickFilterText',
      (document.getElementById('filter-text-box') as HTMLInputElement).value
    );
  }
  // Method to handle grid ready event
  onGridReady(params: any): void {
    this.gridApi = params.api;
  }

  // // This method triggers when the user changes page size or navigates between pages
  // onPaginationChanged(event: any) {
  //   const newPageNumber = event.api.paginationGetCurrentPage() + 1; // Ag-Grid uses zero-based pages
  //   const newPageSize = event.api.paginationGetPageSize();

  //   this.currentPage = newPageNumber;
  //   this.paginationPageSize = newPageSize;
  //   console.log(
  //     'Pagination Change :',
  //     this.currentPage,
  //     ' - ',
  //     this.paginationPageSize
  //   );

  //   // Fetch the new data for the changed page or page size
  //   this.loadGridData(this.currentPage, this.paginationPageSize);
  // }

  onPaginationChanged(event: any) {
    const newPageSize = event.api.paginationGetPageSize();

    this.paginationPageSize = newPageSize;
    // Trigger the data reload by calling the data source
    // event.api.purgeServerSideCache();
  }
  // Called when the Edit button is clicked
  onEdit(row: any): void {
    row.editing = true;
  }

  // Called when the Save button is clicked
  onSave(row: any): void {
    if (this.isInvalid(row.name)) {
      alert('Name cannot be empty and should not contain special characters');
      return;
    }
    row.editing = false;
    // Logic to save the updated data
    this.saveData(row);
  }

  isInvalid(name: string): boolean {
    // Validate that the name is not empty and does not contain special characters
    const specialCharPattern = /[!@#\$%\^\&*\)\(+=._-]/g;
    return !name || specialCharPattern.test(name);
  }

  saveData(row: any): void {
    // Implement your save logic here (could be a call to your backend or a local update)
    console.log('Saving data:', row);
  }
}
