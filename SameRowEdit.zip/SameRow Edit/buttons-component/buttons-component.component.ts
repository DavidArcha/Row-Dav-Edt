import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'app-buttons-component',
  templateUrl: './buttons-component.component.html',
  styleUrl: './buttons-component.component.scss',
})
export class ButtonsComponentComponent {
  params!: ICellRendererParams;
  isEditing: boolean = false;
  rowIndex: number = 0; // Declare rowIndex with a default value

  constructor(private http: HttpClient) {}

  agInit(params: ICellRendererParams): void {
    this.params = params;
    // Ensure rowIndex is a valid number, provide fallback if null
    this.rowIndex =
      params.node && params.node.rowIndex !== null ? params.node.rowIndex : -1;
  }

  // Toggle Edit mode
  toggleEdit(): void {
    this.isEditing = true;
    if (this.rowIndex >= 0) {
      // Ensure rowIndex is valid
      this.params.api.startEditingCell({
        rowIndex: this.rowIndex,
        colKey: 'name', // Adjust this to match the column you want to edit
      });
    } else {
      console.error('Invalid rowIndex:', this.rowIndex);
    }
  }

  // Save and stop editing
  save(): void {
    if (this.rowIndex >= 0) {
      // Stop editing and get the updated data
      this.params.api.stopEditing();

      const updatedRow = this.params.node.data;
      const name = updatedRow.name;
      console.log('New Name:', name);
      if (this.isInvalid(name)) {
        alert('Name cannot be empty or contain special characters.');
        return;
      }
      const apiUrl = `https://your-backend-api-url.com/update/${updatedRow.id}`; // Backend API URL

      // Make an API call to save the edited data
      this.http.put(apiUrl, updatedRow).subscribe(
        (response) => {
          console.log('Row updated successfully', response);
          this.isEditing = false; // Reset the editing mode
        },
        (error) => {
          console.error('Error updating row:', error);
        }
      );
    } else {
      console.error('Invalid rowIndex:', this.rowIndex);
    }
  }

  // Simple validation
  isInvalid(name: string): boolean {
    const specialCharPattern = /[!@#\$%\^\&*\)\(+=._-]/g;
    return !name || specialCharPattern.test(name);
  }
}
